BSSE NFC IET Result Portal
==========================

Developed by: Rana Numan
Department: BS Software Engineering, NFC IET Multan

HOW TO USE:
-----------
1. Open "bsse_portal.html" in any web browser (Chrome, Firefox, Edge)
2. Login with your Roll Number and Form Number

LOGIN CREDENTIALS (56 Students):
--------------------------------
Roll Number: 2k25-BSSE-101 to 2k25-BSSE-156
Password: Form Number from result sheet

Examples:
• 2k25-BSSE-101 | Password: 549 (Roohi Bano)
• 2k25-BSSE-102 | Password: 746 (Meerab Suhail)
• 2k25-BSSE-118 | Password: 1601 (Muhammad Numan)

FEATURES:
---------
✓ Semester 1 Results with GPA/CGPA
✓ Class position/ranking
✓ All 56 students data
✓ Professional NFC IET design
✓ Printable results

SHARING:
--------
Send this ZIP file to anyone. They just need to:
1. Extract the ZIP
2. Open bsse_portal.html
3. No internet required - works offline!

Note: This is a static HTML file. All data is stored in the file itself.
